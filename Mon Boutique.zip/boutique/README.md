# 📱 Application de Gestion de Boutique

## Démarrage rapide

1. Ouvrez le dossier dans **VS Code**
2. Installez l'extension **Live Server** (recommandée)
3. Clic droit sur `index.html` → **Open with Live Server**
4. Ou double-cliquez simplement sur `index.html` dans votre explorateur de fichiers

## Connexion par défaut

| Identifiant | Mot de passe |
|-------------|--------------|
| `admin`     | `admin123`   |

Si une ancienne installation refuse la connexion, ouvrez le nouveau ZIP : au démarrage, l'application vérifie automatiquement la base locale et recrée/répare le compte administrateur principal sans supprimer les autres données.

> ⚠️ Changez le mot de passe dans **Paramètres → Utilisateurs** après la première connexion.

## Structure du projet

```
boutique/
├── index.html              ← Page de connexion (point d'entrée)
├── css/
│   ├── style.css           ← Styles principaux
│   └── login.css           ← Styles de la page connexion
├── js/
│   ├── db.js               ← Base de données locale (localStorage)
│   ├── auth.js             ← Authentification & sessions
│   └── app.js              ← Fonctions communes (sidebar, toast, etc.)
└── pages/
    ├── dashboard.html      ← Tableau de bord
    ├── products.html       ← Gestion des produits
    ├── sales.html          ← Caisse / Point de vente
    ├── purchases.html      ← Achats fournisseurs
    ├── customers.html      ← Clients
    ├── suppliers.html      ← Fournisseurs
    ├── cash.html           ← Caisse & dépenses
    ├── reports.html        ← Rapports & statistiques
    ├── users.html          ← Gestion des utilisateurs
    └── settings.html       ← Paramètres
```

## Fonctionnalités incluses

- ✅ Authentification avec rôles (Admin, Vendeur, Caissier, Magasinier)
- ✅ Tableau de bord avec statistiques en temps réel
- ✅ Gestion des produits avec QR Code, alertes de stock
- ✅ Point de vente (POS) avec panier, remises, modes de paiement
- ✅ Gestion des clients avec historique et crédits
- ✅ Gestion des fournisseurs
- ✅ Achats avec mise à jour automatique du stock
- ✅ Caisse (entrées/sorties/dépenses)
- ✅ Rapports (ventes, stock, dépenses, journal d'activités)
- ✅ Gestion des utilisateurs et permissions
- ✅ Paramètres (nom boutique, devise, thème clair/sombre)
- ✅ Animation de démarrage avec logo TECH-ACCESS puis MARHABA ABK TECHNOLOGY
- ✅ Durées prédéfinies : 15 s (7/8), 30 s (17/13), 60 s (30/30) ou durée personnalisée (50/50)
- ✅ Correction de l'authentification et réparation automatique du compte admin
- ✅ Sauvegarde/Restauration des données (JSON)
- ✅ Responsive (PC, tablette, téléphone)
- ✅ Fonctionne entièrement hors connexion

## Données

Toutes les données sont stockées dans le **localStorage** du navigateur.
Utilisez **Paramètres → Sauvegarde** pour exporter vos données régulièrement.

## Technologies

- HTML5 + CSS3 + JavaScript vanilla
- Aucun framework, aucune dépendance externe
- Fonctionne sans serveur (XAMPP non nécessaire)
